package kr.co.bongdamsafety.onlinemap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinemapApplicationTests {

	@Test
	void contextLoads() {
	}

}
